import padre
print(locals())